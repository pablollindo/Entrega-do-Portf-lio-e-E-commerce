<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Conectar ao banco
try {
    $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
    
    if ($conexao->connect_error) {
        throw new Exception("Erro de conexão: " . $conexao->connect_error);
    }
} catch (Exception $e) {
    die("<h1 style='color: red; text-align: center; margin-top: 50px;'>❌ ERRO: " . $e->getMessage() . "</h1>");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Mensagens - Portfólio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            line-height: 1.6;
            min-height: 100vh;
        }

        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 1rem 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .nav-brand {
            font-weight: 600;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #2c3e50;
        }

        .btn-portfolio {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            border: none;
            border-radius: 10px;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
            color: white;
        }

        .btn-portfolio:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.3);
            background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
        }

        .painel-title {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            color: white;
            font-size: 3.5rem;
            font-weight: 800;
            text-align: center;
            text-transform: uppercase;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(37, 99, 235, 0.2);
            letter-spacing: 2px;
            margin: 2rem 0 1.5rem 0;
            position: relative;
            overflow: hidden;
        }

        .painel-title::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .painel-title:hover::before {
            left: 100%;
        }

        .painel-subtitle {
            font-size: 1.3rem;
            text-align: center;
            color: #475569;
            margin: 2rem 0;
            line-height: 1.8;
            padding: 0 2rem;
            font-weight: 400;
        }

        .container {
            max-width: 1200px;
        }

        .nav-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .nav-brand-container {
            flex: 1;
        }

        .nav-dropdown-container {
            flex: 1;
            display: flex;
            justify-content: center;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            margin-bottom: 2rem;
            text-align: center;
            border-left: 4px solid #2563eb;
        }

        .message-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            margin-bottom: 2rem;
            border-left: 4px solid #10b981;
            transition: all 0.3s ease;
        }

        .message-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0,0,0,0.15);
        }

        .btn-custom {
            border-radius: 10px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            border: none;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            color: white;
        }

        .btn-success-custom {
            background: linear-gradient(135deg, #059669 0%, #10b981 100%);
            color: white;
        }

        .btn-warning-custom {
            background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
            color: white;
        }

        .btn-danger-custom {
            background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
            color: white;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            color: white;
        }

        .message-content {
            background: #f8fafc;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 1rem;
            border-left: 3px solid #e2e8f0;
        }

        .stats-highlight {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            padding: 0.2rem 0.5rem;
            border-radius: 6px;
            font-weight: 600;
            color: #0369a1;
        }

        @media (max-width: 768px) {
            .painel-title {
                font-size: 2.2rem;
                padding: 1.5rem 1rem;
                margin: 1rem 0;
            }

            .painel-subtitle {
                font-size: 1.1rem;
                padding: 0 1rem;
            }

            .message-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container">
            <div class="nav-container">
                <div class="nav-brand-container">
                    <a class="navbar-brand nav-brand">
                        <span>Painel de Mensagens</span>
                    </a>
                </div>
                
                <div class="nav-dropdown-container">
                    <div class="dropdown">
                        <button class="btn btn-portfolio dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-folder me-2"></i>Navegação
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item" href="index.html"><i class="bi bi-person-circle me-2"></i>Portfólio</a></li>
                            <li><a class="dropdown-item" href="tendencias.html"><i class="bi bi-graph-up me-2"></i>Tendências Tecnológicas</a></li>
                            <li><a class="dropdown-item" href="projetos.html"><i class="bi bi-folder me-2"></i>Projetos</a></li>
                            <li><a class="dropdown-item" href="softskills.html"><i class="bi bi-star me-2"></i>Habilidades</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="http://localhost/atividade%20final/p%C3%A1ginas/formulario.html"><i class="bi bi-envelope me-2"></i>Enviar Mensagem</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- TÍTULO PRINCIPAL -->
        <h1 class="painel-title">Painel de Mensagens</h1>

        <!-- SUBTÍTULO -->
        <p class="painel-subtitle">
            Gerencie todas as mensagens recebidas através do formulário de contato. 
            Aqui você pode visualizar, <span class="stats-highlight">editar</span> e 
            <span class="stats-highlight">excluir</span> mensagens, além de acompanhar 
            as <span class="stats-highlight">estatísticas</span> de contato.
        </p>

        <?php
        // Estatísticas
        $sql_count = "SELECT COUNT(*) as total FROM mensagens";
        $result_count = $conexao->query($sql_count);
        $total_mensagens = $result_count->fetch_assoc()['total'];
        ?>
        
        <!-- ESTATÍSTICAS -->
        <div class="stats-card">
            <div class="row">
                <div class="col-md-12">
                    <h3><i class="bi bi-graph-up me-2"></i>ESTATÍSTICAS</h3>
                    <div class="display-4 text-primary"><?php echo $total_mensagens; ?></div>
                    <p class="text-muted">Total de Mensagens Recebidas</p>
                </div>
            </div>
        </div>

        <!-- LISTA DE MENSAGENS -->
        <h2 class="mb-4"><i class="bi bi-chat-text me-2"></i>TODAS AS MENSAGENS</h2>
        
        <?php
        // Buscar todas mensagens
        $sql = "SELECT * FROM mensagens ORDER BY data_envio DESC";
        $resultado = $conexao->query($sql);
        
        if ($resultado->num_rows > 0) {
            while($mensagem = $resultado->fetch_assoc()) {
                echo '
                <div class="message-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h4 class="text-primary"><i class="bi bi-person-circle me-2"></i>' . $mensagem['nome'] . '</h4>
                            <p class="text-muted mb-1"><i class="bi bi-hash me-1"></i>Mensagem #' . $mensagem['id'] . '</p>
                        </div>
                        <span class="badge bg-secondary">' . $mensagem['data_envio'] . '</span>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <p><i class="bi bi-envelope me-2"></i><strong>Email:</strong> ' . $mensagem['email'] . '</p>
                            <p><i class="bi bi-telephone me-2"></i><strong>Telefone:</strong> ' . ($mensagem['telefone'] ?: 'Não informado') . '</p>
                        </div>
                        <div class="col-md-6">
                            <p><i class="bi bi-building me-2"></i><strong>Empresa:</strong> ' . ($mensagem['empresa'] ?: 'Não informada') . '</p>
                            <p><i class="bi bi-chat-dots me-2"></i><strong>Assunto:</strong> ' . $mensagem['assunto'] . '</p>
                        </div>
                    </div>
                    
                    <div class="message-content">
                        <p class="mb-2"><strong><i class="bi bi-chat-quote me-2"></i>Mensagem:</strong></p>
                        ' . nl2br($mensagem['mensagem']) . '
                    </div>
                    
                    <div class="mt-4">
                        <a href="editar_mensagem.php?id=' . $mensagem['id'] . '" class="btn btn-warning-custom btn-custom">
                            <i class="bi bi-pencil me-2"></i>EDITAR
                        </a>
                        <a href="excluir_mensagem.php?id=' . $mensagem['id'] . '" class="btn btn-danger-custom btn-custom" onclick="return confirm(\'Tem certeza que deseja excluir esta mensagem?\')">
                            <i class="bi bi-trash me-2"></i>EXCLUIR
                        </a>
                    </div>
                </div>';
            }
        } else {
            echo '
            <div class="message-card text-center">
                <i class="bi bi-inbox display-1 text-muted mb-3"></i>
                <h3 class="text-muted">Nenhuma mensagem encontrada</h3>
                <p class="text-muted">As mensagens aparecerão aqui quando forem enviadas pelo formulário.</p>
            </div>';
        }
        
        $conexao->close();
        ?>
        
        <!-- BOTÕES DE AÇÃO -->
        <div class="text-center mt-5">
            <a href="formulario.html" class="btn btn-success-custom btn-custom btn-lg">
                <i class="bi bi-plus-circle me-2"></i>NOVA MENSAGEM
            </a>
            <a href="index.html" class="btn btn-primary-custom btn-custom btn-lg">
                <i class="bi bi-house me-2"></i>VOLTAR AO PORTFÓLIO
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Efeito de entrada para as mensagens
        document.addEventListener('DOMContentLoaded', function() {
            const messageCards = document.querySelectorAll('.message-card');
            messageCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                
                setTimeout(() => {
                    card.style.transition = 'all 0.6s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });

            // Inicializar dropdowns do Bootstrap
            var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
            var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
                return new bootstrap.Dropdown(dropdownToggleEl)
            });
        });
    </script>
</body>
</html>