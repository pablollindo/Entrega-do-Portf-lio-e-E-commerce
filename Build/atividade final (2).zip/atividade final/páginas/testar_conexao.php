<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

echo "<h1>Teste Simples MySQL</h1>";

$conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);

if ($conexao->connect_error) {
    echo "<p style='color: red'><strong>ERRO:</strong> " . $conexao->connect_error . "</p>";
} else {
    echo "<p style='color: green'><strong>SUCESSO:</strong> Conectado na porta 3309!</p>";
    
    // Testar inserção
    $sql = "INSERT INTO mensagens (nome, email, assunto, mensagem) 
            VALUES ('Teste', 'teste@teste.com', 'Assunto Teste', 'Mensagem de teste')";
    
    if ($conexao->query($sql)) {
        echo "<p style='color: green'><strong>INSERÇÃO:</strong> Dados salvos! ID: " . $conexao->insert_id . "</p>";
    } else {
        echo "<p style='color: red'><strong>ERRO INSERÇÃO:</strong> " . $conexao->error . "</p>";
    }
    
    $conexao->close();
}
?>