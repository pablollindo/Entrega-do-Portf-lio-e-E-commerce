<?php
// Dados de conexão
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "contato_portfolio";
$porta = 3309;

// Verificar se é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagem Recebida - Portfólio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            line-height: 1.6;
            min-height: 100vh;
        }

        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 1rem 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .nav-brand {
            font-weight: 600;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #2c3e50;
        }

        .btn-portfolio {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            border: none;
            border-radius: 10px;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
            color: white;
        }

        .btn-portfolio:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.3);
            background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
        }

        .success-title {
            background: linear-gradient(135deg, #059669 0%, #10b981 100%);
            color: white;
            font-size: 3.5rem;
            font-weight: 800;
            text-align: center;
            text-transform: uppercase;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(5, 150, 105, 0.2);
            letter-spacing: 2px;
            margin: 2rem 0 1.5rem 0;
            position: relative;
            overflow: hidden;
        }

        .success-title::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .success-title:hover::before {
            left: 100%;
        }

        .success-subtitle {
            font-size: 1.3rem;
            text-align: center;
            color: #475569;
            margin: 2rem 0;
            line-height: 1.8;
            padding: 0 2rem;
            font-weight: 400;
        }

        .container {
            max-width: 800px;
        }

        .nav-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .nav-brand-container {
            flex: 1;
        }

        .nav-dropdown-container {
            flex: 1;
            display: flex;
            justify-content: center;
        }

        .success-card {
            background: white;
            border-radius: 15px;
            padding: 3rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            margin-bottom: 2rem;
            text-align: center;
            border-left: 4px solid #10b981;
        }

        .data-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            margin-bottom: 2rem;
            border-left: 4px solid #2563eb;
        }

        .btn-custom {
            border-radius: 10px;
            padding: 12px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            border: none;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            color: white;
        }

        .btn-info-custom {
            background: linear-gradient(135deg, #0891b2 0%, #06b6d4 100%);
            color: white;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
            color: white;
        }

        .data-item {
            background: #f8fafc;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }

        .id-badge {
            background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
            color: white;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.5rem;
            font-weight: bold;
            display: inline-block;
            margin: 1rem 0;
        }

        .success-highlight {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            padding: 0.2rem 0.5rem;
            border-radius: 6px;
            font-weight: 600;
            color: #0369a1;
        }

        @media (max-width: 768px) {
            .success-title {
                font-size: 2.2rem;
                padding: 1.5rem 1rem;
                margin: 1rem 0;
            }

            .success-subtitle {
                font-size: 1.1rem;
                padding: 0 1rem;
            }

            .success-card, .data-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container">
            <div class="nav-container">
                <div class="nav-brand-container">
                    <a class="navbar-brand nav-brand">
                        <span>Mensagem Recebida</span>
                    </a>
                </div>
                
                <div class="nav-dropdown-container">
                    <div class="dropdown">
                        <button class="btn btn-portfolio dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-folder me-2"></i>Navegação
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item" href="index.html"><i class="bi bi-person-circle me-2"></i>Portfólio</a></li>
                            <li><a class="dropdown-item" href="tendencias.html"><i class="bi bi-graph-up me-2"></i>Tendências Tecnológicas</a></li>
                            <li><a class="dropdown-item" href="projetos.html"><i class="bi bi-folder me-2"></i>Projetos</a></li>
                            <li><a class="dropdown-item" href="softskills.html"><i class="bi bi-star me-2"></i>Habilidades</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="formulario.html"><i class="bi bi-envelope me-2"></i>Enviar Mensagem</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- CABEÇALHO DE SUCESSO -->
        <h1 class="success-title">
            <i class="bi bi-check-circle me-3"></i>MENSAGEM RECEBIDA!
        </h1>

        <!-- SUBTÍTULO -->
        <p class="success-subtitle">
            Sua mensagem foi <span class="success-highlight">enviada com sucesso</span> e está sendo processada. 
            Em breve entrarei em contato através dos dados fornecidos. 
            <span class="success-highlight">Agradeço pelo seu interesse</span>!
        </p>

        <?php
        // Processar e salvar no banco
        try {
            $conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);
            
            if (!$conexao->connect_error) {
                // Inserir dados
                $nome = $conexao->real_escape_string($_POST['nome']);
                $telefone = $conexao->real_escape_string($_POST['telefone']);
                $email = $conexao->real_escape_string($_POST['email']);
                $empresa = $conexao->real_escape_string($_POST['empresa'] ?? '');
                $assunto = $conexao->real_escape_string($_POST['assunto']);
                $mensagem = $conexao->real_escape_string($_POST['mensagem']);
                
                $sql = "INSERT INTO mensagens (nome, telefone, email, empresa, assunto, mensagem) 
                        VALUES ('$nome', '$telefone', '$email', '$empresa', '$assunto', '$mensagem')";
                
                if ($conexao->query($sql)) {
                    $id_mensagem = $conexao->insert_id;
        ?>

        <!-- ID DA MENSAGEM -->
        <div class="success-card">
            <h3 class="mb-3"><i class="bi bi-hash me-2"></i>IDENTIFICADOR DA MENSAGEM</h3>
            <div class="id-badge">
                #<?php echo $id_mensagem; ?>
            </div>
            <p class="text-muted mt-3">
                <i class="bi bi-info-circle me-2"></i>Guarde este número para referência futura
            </p>
        </div>

        <!-- DADOS RECEBIDOS -->
        <div class="data-card">
            <h2 class="mb-4"><i class="bi bi-clipboard-data me-2"></i>DADOS RECEBIDOS</h2>
            
            <div class="data-item">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong><i class="bi bi-person me-2"></i>Nome:</strong><br>
                        <span class="text-primary"><?php echo htmlspecialchars($_POST['nome'] ?? 'Não informado'); ?></span></p>
                        
                        <p><strong><i class="bi bi-envelope me-2"></i>Email:</strong><br>
                        <span class="text-primary"><?php echo htmlspecialchars($_POST['email'] ?? 'Não informado'); ?></span></p>
                        
                        <p><strong><i class="bi bi-telephone me-2"></i>Telefone:</strong><br>
                        <span class="text-primary"><?php echo htmlspecialchars($_POST['telefone'] ?? 'Não informado'); ?></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong><i class="bi bi-building me-2"></i>Empresa:</strong><br>
                        <span class="text-primary"><?php echo htmlspecialchars($_POST['empresa'] ?? 'Não informada'); ?></span></p>
                        
                        <p><strong><i class="bi bi-chat-dots me-2"></i>Assunto:</strong><br>
                        <span class="text-primary"><?php echo htmlspecialchars($_POST['assunto'] ?? 'Não informado'); ?></span></p>
                    </div>
                </div>
                
                <div class="mt-3">
                    <p><strong><i class="bi bi-chat-text me-2"></i>Mensagem:</strong></p>
                    <div class="bg-light p-3 rounded">
                        <?php echo nl2br(htmlspecialchars($_POST['mensagem'] ?? 'Não informada')); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php
                }
                $conexao->close();
            }
        } catch (Exception $e) {
            // Em caso de erro, ainda mostra os dados mas sem o ID
        ?>
        <div class="alert alert-danger text-center">
            <i class="bi bi-exclamation-triangle me-2"></i>
            <strong>Erro no banco de dados:</strong> Sua mensagem foi recebida mas não foi possível gerar o ID.
        </div>
        <?php
        }
        ?>

        <!-- BOTÕES DE AÇÃO -->
        <div class="text-center mt-4">
            <a href="formulario.html" class="btn btn-primary-custom btn-custom btn-lg">
                <i class="bi bi-arrow-left me-2"></i>VOLTAR AO FORMULÁRIO
            </a>
            <a href="painel_mensagens.php" class="btn btn-info-custom btn-custom btn-lg">
                <i class="bi bi-speedometer2 me-2"></i>VER TODAS MENSAGENS
            </a>
            <a href="index.html" class="btn btn-secondary btn-custom btn-lg">
                <i class="bi bi-house me-2"></i>VOLTAR AO PORTFÓLIO
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Efeito de entrada
        document.addEventListener('DOMContentLoaded', function() {
            const elements = document.querySelectorAll('.success-card, .data-card');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                
                setTimeout(() => {
                    el.style.transition = 'all 0.6s ease';
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, index * 200);
            });

            // Inicializar dropdowns do Bootstrap
            var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
            var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
                return new bootstrap.Dropdown(dropdownToggleEl)
            });
        });
    </script>
</body>
</html>
<?php
} else {
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso Negado - Portfólio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .error-card {
            background: white;
            border-radius: 15px;
            padding: 3rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
            text-align: center;
            max-width: 500px;
            width: 100%;
            border-left: 4px solid #dc2626;
        }
        .btn-custom {
            border-radius: 10px;
            padding: 10px 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="text-warning mb-4">
            <i class="bi bi-exclamation-triangle display-1"></i>
            <h2 class="mt-3">⚠️ ACESSO NEGADO</h2>
            <p class="text-muted">Esta página só pode ser acessada através do formulário.</p>
        </div>
        
        <a href="formulario.html" class="btn btn-primary btn-custom">
            <i class="bi bi-arrow-right me-2"></i>IR PARA O FORMULÁRIO
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
}